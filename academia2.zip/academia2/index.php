<?php
// Redirigir todas las solicitudes al directorio public
header('Location: public/index.php');
exit();
