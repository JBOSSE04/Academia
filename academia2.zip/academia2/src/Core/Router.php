<?php

namespace App\Core;

class Router
{
    private array $routes = [];
    private array $middlewares = [];
    private $notFoundHandler;

    public function add(string $method, string $path, array $handler): void
    {
        $this->routes[] = [
            'method' => $method,
            'path' => $path,
            'handler' => $handler
        ];
    }

    public function get(string $path, array $handler): void
    {
        $this->add('GET', $path, $handler);
    }

    public function post(string $path, array $handler): void
    {
        $this->add('POST', $path, $handler);
    }

    public function addMiddleware(callable $middleware): void
    {
        $this->middlewares[] = $middleware;
    }

    public function setNotFoundHandler(callable $handler): void
    {
        $this->notFoundHandler = $handler;
    }

    private function matchRoute(string $requestPath, string $routePath): ?array
    {
        $routeParts = explode('/', trim($routePath, '/'));
        $requestParts = explode('/', trim($requestPath, '/'));

        if (count($routeParts) !== count($requestParts)) {
            return null;
        }

        $params = [];
        for ($i = 0; $i < count($routeParts); $i++) {
            if (strpos($routeParts[$i], ':') === 0) {
                $params[substr($routeParts[$i], 1)] = $requestParts[$i];
            } elseif ($routeParts[$i] !== $requestParts[$i]) {
                return null;
            }
        }

        return $params;
    }

    private function handleNotFound(): void
    {
        if (is_callable($this->notFoundHandler)) {
            call_user_func($this->notFoundHandler);
        } else {
            http_response_code(404);
            require_once __DIR__ . '/../../views/errors/404.php';
        }
    }

    public function dispatch(): void
    {
        try {
            $requestMethod = $_SERVER['REQUEST_METHOD'];
            $requestPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

            // Ejecutar middlewares
            foreach ($this->middlewares as $middleware) {
                $middleware();
            }

            foreach ($this->routes as $route) {
                if ($route['method'] !== $requestMethod) {
                    continue;
                }

                $params = $this->matchRoute($requestPath, $route['path']);
                if ($params !== null) {
                    [$controller, $method] = $route['handler'];
                    $controllerInstance = new $controller();
                    call_user_func_array([$controllerInstance, $method], $params);
                    return;
                }
            }

            // Si no se encuentra la ruta
            $this->handleNotFound();
        } catch (\Exception $e) {
            error_log($e->getMessage());
            http_response_code(500);
            require_once __DIR__ . '/../../views/errors/500.php';
        }
    }
}
