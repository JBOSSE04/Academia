<?php

namespace App\Services;

use Dompdf\Dompdf;
use Dompdf\Options;

class PDFService
{
    private Dompdf $dompdf;

    public function __construct()
    {
        $options = new Options();
        $options->set('isHtml5ParserEnabled', true);
        $options->set('isPhpEnabled', true);
        
        $this->dompdf = new Dompdf($options);
    }

    public function generarBoletinNotas(array $datosAlumno, array $notas): string
    {
        $html = '
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; }
                .header { text-align: center; margin-bottom: 30px; }
                .titulo { font-size: 24px; margin-bottom: 10px; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #f5f5f5; }
                .alumno-info { margin-bottom: 20px; }
                .footer { margin-top: 30px; text-align: center; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class="header">
                <div class="titulo">Boletín de Notas</div>
                <div>Academia Los Excelentes</div>
            </div>
            
            <div class="alumno-info">
                <strong>Alumno:</strong> ' . htmlspecialchars($datosAlumno['nombre'] . ' ' . 
                                                            $datosAlumno['apellido1'] . ' ' . 
                                                            $datosAlumno['apellido2']) . '<br>
                <strong>Fecha:</strong> ' . date('d/m/Y') . '
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Materia</th>
                        <th>Trimestre</th>
                        <th>Nota</th>
                    </tr>
                </thead>
                <tbody>';

        foreach ($notas as $nota) {
            $html .= '
                    <tr>
                        <td>' . htmlspecialchars($nota['materia']) . '</td>
                        <td>' . htmlspecialchars($nota['trimestre']) . '</td>
                        <td>' . htmlspecialchars(number_format($nota['nota'], 2)) . '</td>
                    </tr>';
        }

        $html .= '
                </tbody>
            </table>

            <div class="footer">
                Este documento es un informe oficial de las calificaciones del alumno.
            </div>
        </body>
        </html>';

        $this->dompdf->loadHtml($html);
        $this->dompdf->setPaper('A4', 'portrait');
        $this->dompdf->render();

        return $this->dompdf->output();
    }

    public function generarPDF(string $html, string $nombreArchivo): string
    {
        $this->dompdf->loadHtml($html);
        $this->dompdf->setPaper('A4', 'portrait');
        $this->dompdf->render();

        $rutaDirectorio = __DIR__ . '/../../public/assets/informes/';
        if (!file_exists($rutaDirectorio)) {
            mkdir($rutaDirectorio, 0777, true);
        }

        $id = uniqid();
        $rutaArchivo = $rutaDirectorio . $id . '_' . $nombreArchivo;
        
        file_put_contents($rutaArchivo, $this->dompdf->output());
        
        return $id;
    }

    public function obtenerRutaInforme(string $id): string
    {
        $rutaDirectorio = __DIR__ . '/../../public/assets/informes/';
        $archivos = glob($rutaDirectorio . $id . '_*');
        
        if (empty($archivos)) {
            throw new \RuntimeException('Informe no encontrado');
        }
        
        return $archivos[0];
    }
}
