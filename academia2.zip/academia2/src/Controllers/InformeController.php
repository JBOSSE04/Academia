<?php

namespace App\Controllers;

use App\Services\PDFService;
use App\Repository\NotaRepository;
use App\Repository\UsuarioRepository;

class InformeController extends BaseController
{
    private NotaRepository $notaRepository;
    private UsuarioRepository $usuarioRepository;
    private PDFService $pdfService;

    public function __construct()
    {
        parent::__construct();
        $this->notaRepository = new NotaRepository();
        $this->usuarioRepository = new UsuarioRepository();
        $this->pdfService = new PDFService();
    }

    public function index(): void
    {
        $this->cargarAlumnos();
        $this->render('informes/index', ['alumnos' => $this->viewData['alumnos']]);
    }

    public function generarForm(): void
    {
        $this->requireRole('gestor', 'profesor', 'alumno');
        $this->cargarAlumnos();
        $this->render('informes/generar', ['alumnos' => $this->viewData['alumnos']]);
    }

    public function generar(): void
    {
        $this->requireRole('gestor', 'profesor', 'alumno');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/informes/generar');
        }

        $data = $this->getPostData(['alumno_id', 'tipo_informe']);
        $alumnoId = (int)$data['alumno_id'];

        // Validar datos
        $errors = $this->validateRequired($data, [
            'alumno_id' => 'El alumno es obligatorio',
            'tipo_informe' => 'El tipo de informe es obligatorio'
        ]);

        if (!empty($errors) || $alumnoId <= 0) {
            $this->redirect('/informes/generar', ['error' => 'Datos inválidos']);
        }

        // Verificar permisos para ver el alumno
        if ($_SESSION['rol'] === 'alumno' && $_SESSION['user_id'] !== $alumnoId) {
            $this->redirect('/informes', ['error' => 'No tienes permiso para ver este alumno']);
        }

        try {
            // Obtener datos según el tipo de informe
            $datos = $this->obtenerDatosInforme($alumnoId, $data['tipo_informe']);
            if (empty($datos)) {
                $this->redirect('/informes/generar', ['error' => 'No hay datos para generar el informe']);
            }

            // Obtener información del alumno
            $alumno = $this->usuarioRepository->findById($alumnoId);
            if (!$alumno) {
                throw new \RuntimeException('Alumno no encontrado');
            }

            // Generar PDF
            $nombreArchivo = $this->generarNombreArchivo($alumno, $data['tipo_informe']);
            $html = $this->generarContenidoInforme($datos, $alumno, $data['tipo_informe']);
            
            $this->pdfService->generarPDF($html, $nombreArchivo);
            
        } catch (\Exception $e) {
            error_log("Error al generar informe: " . $e->getMessage());
            $this->redirect('/informes/generar', ['error' => 'Error al generar el informe']);
        }
    }

    public function descargar(string $id): void
    {
        $this->requireRole('gestor', 'profesor', 'alumno');

        try {
            $rutaArchivo = $this->pdfService->obtenerRutaInforme($id);
            if (!file_exists($rutaArchivo)) {
                throw new \RuntimeException('El archivo no existe');
            }

            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . basename($rutaArchivo) . '"');
            header('Content-Length: ' . filesize($rutaArchivo));
            readfile($rutaArchivo);
            exit();

        } catch (\Exception $e) {
            error_log("Error al descargar informe: " . $e->getMessage());
            $this->redirect('/informes', ['error' => 'Error al descargar el informe']);
        }
    }

    private function cargarAlumnos(): void
    {
        if ($_SESSION['rol'] === 'gestor' || $_SESSION['rol'] === 'profesor') {
            $this->viewData['alumnos'] = $this->usuarioRepository->listarAlumnos();
        } elseif ($_SESSION['rol'] === 'alumno') {
            // Si es alumno, solo puede ver sus propias notas
            $alumno = $this->usuarioRepository->findById($_SESSION['user_id']);
            $this->viewData['alumnos'] = $alumno ? [$alumno] : [];
        }
    }

    private function tienePermisoParaAlumno(int $alumnoId): bool
    {
        if ($_SESSION['rol'] === 'gestor' || $_SESSION['rol'] === 'profesor') {
            return true;
        }
        // Si es alumno, solo puede ver sus propias notas
        return $_SESSION['rol'] === 'alumno' && $_SESSION['user_id'] === $alumnoId;
    }

    private function obtenerDatosInforme(int $alumnoId, string $tipoInforme): array
    {
        return match($tipoInforme) {
            'notas' => $this->notaRepository->obtenerNotasAlumno($alumnoId),
            'promedios' => $this->notaRepository->obtenerPromediosAlumno($alumnoId),
            default => throw new \InvalidArgumentException('Tipo de informe no válido')
        };
    }

    private function generarNombreArchivo(array $alumno, string $tipoInforme): string
    {
        $fecha = date('Y-m-d');
        $nombreAlumno = sprintf(
            '%s_%s_%s',
            $alumno['apellido1'],
            $alumno['apellido2'],
            $alumno['nombre']
        );
        return sprintf(
            'informe_%s_%s_%s.pdf',
            $tipoInforme,
            strtolower($this->cleanInput($nombreAlumno)),
            $fecha
        );
    }

    private function generarContenidoInforme(array $datos, array $alumno, string $tipoInforme): string
    {
        $nombreCompleto = sprintf(
            '%s %s, %s',
            $alumno['apellido1'],
            $alumno['apellido2'],
            $alumno['nombre']
        );

        $html = '<h1>Informe de ' . ucfirst($tipoInforme) . '</h1>';
        $html .= '<h2>Alumno: ' . htmlspecialchars($nombreCompleto) . '</h2>';
        $html .= '<h3>Fecha: ' . date('d/m/Y') . '</h3>';

        if ($tipoInforme === 'notas') {
            $html .= $this->generarTablaNotas($datos);
        } else {
            $html .= $this->generarTablaPromedios($datos);
        }

        return $html;
    }

    private function generarTablaNotas(array $notas): string
    {
        $html = '<table border="1" cellpadding="5">';
        $html .= '<tr><th>Materia</th><th>Nota</th><th>Fecha</th><th>Profesor</th></tr>';
        
        foreach ($notas as $nota) {
            $html .= sprintf(
                '<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>',
                htmlspecialchars($nota['materia_nombre']),
                number_format($nota['valor'], 2),
                date('d/m/Y', strtotime($nota['fecha'])),
                htmlspecialchars($nota['profesor_nombre'])
            );
        }
        
        $html .= '</table>';
        return $html;
    }

    private function generarTablaPromedios(array $promedios): string
    {
        $html = '<table border="1" cellpadding="5">';
        $html .= '<tr><th>Materia</th><th>Promedio</th><th>Notas Totales</th></tr>';
        
        foreach ($promedios as $promedio) {
            $html .= sprintf(
                '<tr><td>%s</td><td>%s</td><td>%d</td></tr>',
                htmlspecialchars($promedio['materia_nombre']),
                number_format($promedio['promedio'], 2),
                $promedio['total_notas']
            );
        }
        
        $html .= '</table>';
        return $html;
    }
}
