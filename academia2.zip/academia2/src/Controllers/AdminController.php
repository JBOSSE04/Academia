<?php

namespace App\Controllers;

class AdminController extends BaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->checkRole(['administrador']);
    }

    public function dashboard(): void
    {
        $this->render('admin/dashboard', [
            'titulo' => 'Panel de Administrador',
            'usuario' => $_SESSION['user']
        ]);
    }
}
