<?php

namespace App\Controllers;

class ProfesorController extends BaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->checkRole(['profesor']);
    }

    public function dashboard(): void
    {
        $this->render('profesores/dashboard', [
            'titulo' => 'Panel de Profesor',
            'usuario' => $_SESSION['user']
        ]);
    }
}
