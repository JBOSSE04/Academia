<?php

namespace App\Controllers;

use App\Services\AuthService;

class AuthController extends BaseController
{
    private AuthService $authService;

    public function __construct()
    {
        $this->authService = new AuthService();
        parent::__construct();
    }

    public function loginForm(): void
    {
        if (isset($_SESSION['user_id'])) {
            $this->redirect('/');
        }
        
        $this->render('auth/login');
    }

    public function login(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/login');
        }

        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';

        // Log para depuración
        error_log("Intento de login - Email: " . $email);

        if (empty($email) || empty($password)) {
            $this->setFlash('error', 'Por favor, complete todos los campos.');
            $this->redirect('/login');
            return;
        }

        $usuario = $this->authService->login($email, $password);

        if ($usuario) {
            error_log("Login exitoso para el usuario: " . $email);
            
            $_SESSION['user_id'] = $usuario['id'];
            $_SESSION['user'] = [
                'id' => $usuario['id'],
                'email' => $usuario['email'],
                'nombre' => $usuario['nombre'],
                'apellido1' => $usuario['apellido1'],
                'apellido2' => $usuario['apellido2'],
                'rol' => $usuario['tipo_usuario']
            ];
            $_SESSION['rol'] = $usuario['tipo_usuario'];
            
            // Redirección basada en el rol del usuario
            switch ($usuario['tipo_usuario']) {
                case 'administrador':
                    $this->redirect('/admin/dashboard');
                    break;
                case 'profesor':
                    $this->redirect('/profesores/dashboard');
                    break;
                case 'tutor':
                    $this->redirect('/tutores/dashboard');
                    break;
                case 'alumno':
                    $this->redirect('/alumnos/dashboard');
                    break;
                default:
                    $this->redirect('/');
            }
        } else {
            error_log("Login fallido para el usuario: " . $email);
            $this->setFlash('error', 'Usuario o contraseña incorrectos');
            $this->redirect('/login');
        }
    }

    public function logout(): void
    {
        session_destroy();
        $this->redirect('/login');
    }

    public function cambiarPasswordForm(): void
    {
        if (!isset($_SESSION['user_id'])) {
            $this->redirect('/');
        }

        $this->render('auth/cambiar-password');
    }

    public function cambiarPassword(): void
    {
        if (!isset($_SESSION['user_id'])) {
            $this->redirect('/');
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/cambiar-password');
        }

        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        // Validaciones
        if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
            $this->setFlash('error', 'Por favor, complete todos los campos.');
            $this->redirect('/cambiar-password');
            return;
        }

        if ($newPassword !== $confirmPassword) {
            $this->setFlash('error', 'Las contraseñas nuevas no coinciden.');
            $this->redirect('/cambiar-password');
            return;
        }

        // Verificar contraseña actual y actualizar
        if ($this->authService->actualizarPassword($_SESSION['user_id'], $newPassword)) {
            $this->setFlash('success', 'Contraseña actualizada correctamente.');
            $this->redirect('/dashboard');
        } else {
            $this->setFlash('error', 'Error al actualizar la contraseña.');
            $this->redirect('/cambiar-password');
        }
    }
}
