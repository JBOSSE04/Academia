<?php

namespace App\Controllers;

abstract class BaseController
{
    protected array $viewData = [];
    protected array $errors = [];

    public function __construct()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Verificar si el usuario está autenticado (excepto para AuthController)
        if (!$this instanceof AuthController && 
            (!isset($_SESSION['user_id']) || empty($_SESSION['user_id']))) {
            header('Location: /login');
            exit();
        }

        // Datos comunes para todas las vistas
        $this->viewData['user'] = $_SESSION['user'] ?? null;
        $this->viewData['rol'] = $_SESSION['rol'] ?? null;
        $this->viewData['mensaje'] = $_GET['mensaje'] ?? null;
        $this->viewData['error'] = $_GET['error'] ?? null;
    }

    protected function render(string $view, array $data = []): void
    {
        // Extraer los datos para que estén disponibles en la vista
        extract($data);
        
        // Incluir la vista
        require_once __DIR__ . '/../../public/views/' . $view . '.php';
    }

    protected function redirect(string $path, array $params = []): void
    {
        $baseUrl = rtrim($_ENV['APP_URL'] ?? 'http://localhost:8000', '/');
        $url = $baseUrl . '/' . ltrim($path, '/');
        
        if (!empty($params)) {
            $url .= '?' . http_build_query($params);
        }
        
        header("Location: {$url}");
        exit();
    }

    protected function getPostData(array $fields): array
    {
        $data = [];
        foreach ($fields as $field) {
            $data[$field] = $_POST[$field] ?? null;
        }
        return $data;
    }

    protected function validateRequired(array $data, array $fields): array
    {
        $errors = [];
        foreach ($fields as $field => $message) {
            if (empty($data[$field])) {
                $errors[$field] = $message;
            }
        }
        return $errors;
    }

    protected function checkAuth(): void
    {
        if (!isset($_SESSION['user_id'])) {
            $this->redirect('/login');
        }
    }

    protected function checkRole(array $allowedRoles): void
    {
        $this->checkAuth();
        
        if (!in_array($_SESSION['rol'], $allowedRoles)) {
            $this->redirect('/');
        }
    }

    protected function json(array $data, int $statusCode = 200): void
    {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit();
    }

    protected function requireRole(string ...$roles): void
    {
        if (!isset($_SESSION['rol']) || !in_array($_SESSION['rol'], $roles)) {
            if ($this->isAjaxRequest()) {
                $this->json(['error' => 'No tienes permiso para realizar esta acción'], 403);
            } else {
                $this->redirect('/', ['error' => 'No tienes permiso para acceder a esta página']);
            }
        }
    }

    protected function isAjaxRequest(): bool
    {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }

    protected function validateEmail(string $email): bool
    {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }

    protected function validateDNI(string $dni): bool
    {
        return preg_match('/^[0-9]{8}[A-Z]$/', $dni) === 1;
    }

    protected function cleanInput(string $input): string
    {
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    }

    protected function setFlash(string $type, string $message): void
    {
        $_SESSION['flash'][$type] = $message;
    }

    protected function getFlash(string $type): ?string
    {
        if (isset($_SESSION['flash'][$type])) {
            $message = $_SESSION['flash'][$type];
            unset($_SESSION['flash'][$type]);
            return $message;
        }
        return null;
    }

    protected function hasFlash(string $type): bool
    {
        return isset($_SESSION['flash'][$type]);
    }
}
