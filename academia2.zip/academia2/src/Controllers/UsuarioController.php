<?php

namespace App\Controllers;

use App\Services\AuthService;
use App\Repository\UsuarioRepository;

class UsuarioController extends BaseController
{
    private UsuarioRepository $usuarioRepository;
    private AuthService $authService;

    public function __construct()
    {
        parent::__construct();
        $this->usuarioRepository = new UsuarioRepository();
        $this->authService = new AuthService();
    }

    public function index(): void
    {
        try {
            $this->requireRole('gestor');
            
            $usuarios = $this->usuarioRepository->listarTodos();
            $this->render('usuarios/index', [
                'usuarios' => $usuarios
            ]);
        } catch (\Exception $e) {
            $this->render('error', [
                'mensaje' => 'Error al cargar la página de usuarios',
                'error' => $e->getMessage()
            ]);
        }
    }

    public function registroForm(): void
    {
        try {
            $this->requireRole('gestor');
            
            $roles = $this->usuarioRepository->getRoles();
            $this->render('usuarios/registro', [
                'roles' => $roles
            ]);
        } catch (\Exception $e) {
            $this->render('error', [
                'mensaje' => 'Error al cargar el formulario de registro',
                'error' => $e->getMessage()
            ]);
        }
    }

    public function registrar(): void
    {
        try {
            $this->requireRole('gestor');

            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                header('Location: /usuarios/registro');
                exit();
            }

            $datos = [
                'nombre' => trim($_POST['nombre'] ?? ''),
                'apellido1' => trim($_POST['apellido1'] ?? ''),
                'apellido2' => trim($_POST['apellido2'] ?? ''),
                'dni' => trim($_POST['dni'] ?? ''),
                'email' => trim($_POST['email'] ?? ''),
                'rol_id' => (int)($_POST['rol_id'] ?? 0)
            ];

            // Validar que el rol_id existe
            $roles = $this->usuarioRepository->getRoles();
            $rolValido = false;
            foreach ($roles as $rol) {
                if ($rol['id'] === $datos['rol_id']) {
                    $rolValido = true;
                    break;
                }
            }
            
            if (!$rolValido) {
                $this->mostrarFormularioConErrores(['El rol seleccionado no es válido'], $datos);
                return;
            }

            $errores = $this->validarDatosUsuario($datos);

            if (!empty($errores)) {
                $this->mostrarFormularioConErrores($errores, $datos);
                return;
            }

            // Generar credenciales
            $username = $this->authService->generarUsername(
                $datos['nombre'], 
                $datos['apellido1'], 
                $datos['apellido2'], 
                $datos['dni']
            );
            $password = $this->authService->generarPassword();

            // Preparar datos para crear usuario
            $datosUsuario = array_merge($datos, [
                'username' => $username,
                'password' => password_hash($password, PASSWORD_DEFAULT),
                'primer_login' => true
            ]);

            // Crear usuario
            $userId = $this->usuarioRepository->crear($datosUsuario);
            if (!$userId) {
                $this->mostrarFormularioConErrores(['Error al crear el usuario'], $datos);
                return;
            }

            // Enviar credenciales por email
            if (!$this->authService->enviarPasswordPorEmail($datos['email'], $password, $username)) {
                $this->usuarioRepository->eliminar($userId);
                $this->mostrarFormularioConErrores(
                    ['Error al enviar las credenciales por email. El usuario no ha sido creado.'], 
                    $datos
                );
                return;
            }

            header('Location: /usuarios?mensaje=Usuario registrado correctamente');
            exit();
        } catch (\Exception $e) {
            $this->render('error', [
                'mensaje' => 'Error al registrar el usuario',
                'error' => $e->getMessage()
            ]);
        }
    }

    public function editarForm(int $id): void
    {
        try {
            $this->requireRole('gestor');
            
            $usuario = $this->usuarioRepository->obtenerPorId($id);
            if (!$usuario) {
                header('Location: /usuarios?error=Usuario no encontrado');
                exit();
            }

            $roles = $this->usuarioRepository->getRoles();
            $this->render('usuarios/editar', [
                'usuario' => $usuario,
                'roles' => $roles
            ]);
        } catch (\Exception $e) {
            $this->render('error', [
                'mensaje' => 'Error al cargar el formulario de edición',
                'error' => $e->getMessage()
            ]);
        }
    }

    public function editar(int $id): void
    {
        try {
            $this->requireRole('gestor');

            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                header('Location: /usuarios');
                exit();
            }

            $usuario = $this->usuarioRepository->obtenerPorId($id);
            if (!$usuario) {
                header('Location: /usuarios?error=Usuario no encontrado');
                exit();
            }

            $datos = [
                'nombre' => trim($_POST['nombre'] ?? ''),
                'apellido1' => trim($_POST['apellido1'] ?? ''),
                'apellido2' => trim($_POST['apellido2'] ?? ''),
                'dni' => trim($_POST['dni'] ?? ''),
                'email' => trim($_POST['email'] ?? ''),
                'rol_id' => (int)($_POST['rol_id'] ?? 0)
            ];

            // Validar que el rol_id existe
            $roles = $this->usuarioRepository->getRoles();
            $rolValido = false;
            foreach ($roles as $rol) {
                if ($rol['id'] === $datos['rol_id']) {
                    $rolValido = true;
                    break;
                }
            }
            
            if (!$rolValido) {
                $this->render('usuarios/editar', [
                    'usuario' => array_merge($usuario, $datos),
                    'roles' => $roles,
                    'errores' => ['El rol seleccionado no es válido']
                ]);
                return;
            }

            $errores = $this->validarDatosUsuario($datos, $id);

            if (!empty($errores)) {
                $roles = $this->usuarioRepository->getRoles();
                $this->render('usuarios/editar', [
                    'usuario' => array_merge($usuario, $datos),
                    'roles' => $roles,
                    'errores' => $errores
                ]);
                return;
            }

            if ($this->usuarioRepository->actualizar($id, $datos)) {
                header('Location: /usuarios?mensaje=Usuario actualizado correctamente');
                exit();
            } else {
                $roles = $this->usuarioRepository->getRoles();
                $this->render('usuarios/editar', [
                    'usuario' => array_merge($usuario, $datos),
                    'roles' => $roles,
                    'errores' => ['Error al actualizar el usuario']
                ]);
            }
        } catch (\Exception $e) {
            $this->render('error', [
                'mensaje' => 'Error al editar el usuario',
                'error' => $e->getMessage()
            ]);
        }
    }

    public function eliminar(int $id): void
    {
        try {
            $this->requireRole('gestor');

            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                header('HTTP/1.1 405 Method Not Allowed');
                echo json_encode(['error' => 'Método no permitido']);
                exit();
            }

            // Evitar que un gestor se elimine a sí mismo
            if ($id === $_SESSION['user_id']) {
                header('HTTP/1.1 400 Bad Request');
                echo json_encode(['error' => 'No puedes eliminar tu propio usuario']);
                exit();
            }

            // Verificar que el usuario existe
            $usuario = $this->usuarioRepository->obtenerPorId($id);
            if (!$usuario) {
                header('HTTP/1.1 404 Not Found');
                echo json_encode(['error' => 'Usuario no encontrado']);
                exit();
            }

            if ($this->usuarioRepository->eliminar($id)) {
                echo json_encode(['mensaje' => 'Usuario eliminado correctamente']);
            } else {
                header('HTTP/1.1 500 Internal Server Error');
                echo json_encode(['error' => 'Error al eliminar el usuario']);
            }
            exit();
        } catch (\Exception $e) {
            $this->render('error', [
                'mensaje' => 'Error al eliminar el usuario',
                'error' => $e->getMessage()
            ]);
        }
    }

    private function validarDatosUsuario(array $datos, ?int $id = null): array
    {
        $errores = [];

        if (empty($datos['nombre'])) $errores[] = 'El nombre es obligatorio';
        if (empty($datos['apellido1'])) $errores[] = 'El primer apellido es obligatorio';
        if (empty($datos['apellido2'])) $errores[] = 'El segundo apellido es obligatorio';
        if (empty($datos['dni'])) {
            $errores[] = 'El DNI es obligatorio';
        } elseif (!preg_match('/^[0-9]{8}[A-Z]$/', $datos['dni'])) {
            $errores[] = 'El formato del DNI no es válido';
        } elseif ($this->usuarioRepository->existeDNI($datos['dni'], $id)) {
            $errores[] = 'El DNI ya está registrado';
        }

        if (empty($datos['email'])) {
            $errores[] = 'El email es obligatorio';
        } elseif (!filter_var($datos['email'], FILTER_VALIDATE_EMAIL)) {
            $errores[] = 'El formato del email no es válido';
        } elseif ($this->usuarioRepository->existeEmail($datos['email'], $id)) {
            $errores[] = 'El email ya está registrado';
        }

        if ($datos['rol_id'] <= 0) $errores[] = 'El rol es obligatorio';

        return $errores;
    }

    private function mostrarFormularioConErrores(array $errores, array $datos): void
    {
        $roles = $this->usuarioRepository->getRoles();
        $this->render('usuarios/registro', [
            'roles' => $roles,
            'errores' => $errores,
            'old' => $datos
        ]);
    }
}
