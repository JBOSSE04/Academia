<?php

namespace App\Controllers;

use App\Repository\NotaRepository;
use App\Repository\MateriaRepository;
use App\Repository\UsuarioRepository;
use App\Services\PDFService;
use App\Config\Database;

class NotaController extends BaseController
{
    private NotaRepository $notaRepository;
    private MateriaRepository $materiaRepository;
    private UsuarioRepository $usuarioRepository;
    private PDFService $pdfService;
    private $db;

    public function __construct()
    {
        parent::__construct();
        $this->notaRepository = new NotaRepository();
        $this->materiaRepository = new MateriaRepository();
        $this->usuarioRepository = new UsuarioRepository();
        $this->pdfService = new PDFService();
        $this->db = Database::getInstance()->getConnection();
    }

    public function index(): void
    {
        $this->requireRole('gestor', 'profesor', 'alumno');
        
        try {
            if ($_SESSION['rol'] === 'alumno') {
                $materias = $this->materiaRepository->obtenerMateriasDeAlumno($_SESSION['user_id']);
            } else {
                $materias = $_SESSION['rol'] === 'gestor' 
                    ? $this->materiaRepository->listar()
                    : $this->materiaRepository->obtenerMateriasPorProfesor($_SESSION['user_id']);
            }

            $this->render('notas/index', ['materias' => $materias]);
        } catch (\Exception $e) {
            error_log("Error al cargar notas: " . $e->getMessage());
            $this->redirect('/notas', ['error' => 'Error al cargar las notas']);
        }
    }

    public function listar(): void
    {
        try {
            $materiaId = isset($_GET['materia_id']) ? (int)$_GET['materia_id'] : 0;
            $trimestre = isset($_GET['trimestre']) ? (int)$_GET['trimestre'] : 0;

            if ($materiaId <= 0 || $trimestre <= 0 || $trimestre > 3) {
                $this->redirect('/notas', ['error' => 'Parámetros incorrectos']);
                return;
            }

            // Verificar permisos para profesor
            if ($_SESSION['rol'] === 'profesor' && !$this->tienePermisoParaMateria($materiaId)) {
                $this->redirect('/notas', ['error' => 'No tienes permisos para ver estas notas']);
                return;
            }

            $notas = $this->notaRepository->obtenerNotasPorMateriaYTrimestre($materiaId, $trimestre);
            $materia = $this->materiaRepository->obtenerPorId($materiaId);
            if (!$materia) {
                throw new \RuntimeException('Materia no encontrada');
            }

            $alumnos = $this->usuarioRepository->listarAlumnos();

            $this->render('notas/listar', [
                'notas' => $notas,
                'materia' => $materia,
                'trimestre' => $trimestre,
                'alumnos' => $alumnos
            ]);

        } catch (\Exception $e) {
            error_log("Error al listar notas: " . $e->getMessage());
            $this->redirect('/notas', ['error' => 'Error al cargar las notas']);
        }
    }

    public function crear(): void
    {
        $this->requireRole('gestor', 'profesor');
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/notas');
            return;
        }

        try {
            $alumnoId = isset($_POST['alumno_id']) ? (int)$_POST['alumno_id'] : 0;
            $materiaId = isset($_POST['materia_id']) ? (int)$_POST['materia_id'] : 0;
            $trimestre = isset($_POST['trimestre']) ? (int)$_POST['trimestre'] : 0;
            $nota = isset($_POST['nota']) ? (float)$_POST['nota'] : -1;

            // Validaciones básicas
            if ($alumnoId <= 0 || $materiaId <= 0 || $trimestre <= 0 || $trimestre > 3) {
                throw new \InvalidArgumentException('Datos inválidos');
            }

            if ($nota < 0 || $nota > 10) {
                throw new \InvalidArgumentException('La nota debe estar entre 0 y 10');
            }

            // Verificar permisos para profesor
            if ($_SESSION['rol'] === 'profesor' && !$this->tienePermisoParaMateria($materiaId)) {
                throw new \RuntimeException('No tienes permisos para esta materia');
            }

            // Verificar que el alumno existe
            if (!$this->usuarioRepository->existeAlumno($alumnoId)) {
                throw new \RuntimeException('Alumno no encontrado');
            }

            $notaData = [
                'alumno_id' => $alumnoId,
                'materia_id' => $materiaId,
                'trimestre' => $trimestre,
                'nota' => $nota,
                'profesor_id' => $_SESSION['user_id']
            ];

            if (!$this->notaRepository->crear($notaData)) {
                throw new \RuntimeException('Ya existe una nota para este alumno en esta materia y trimestre');
            }

            $this->redirect('/notas/listar', [
                'materia_id' => $materiaId,
                'trimestre' => $trimestre,
                'mensaje' => 'Nota agregada correctamente'
            ]);

        } catch (\Exception $e) {
            error_log("Error al crear nota: " . $e->getMessage());
            $this->redirect('/notas', ['error' => $e->getMessage()]);
        }
    }

    public function editar(): void
    {
        $this->requireRole('gestor', 'profesor');
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/notas');
            return;
        }

        try {
            $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
            $nota = isset($_POST['nota']) ? (float)$_POST['nota'] : -1;

            if ($id <= 0) {
                throw new \InvalidArgumentException('ID de nota inválido');
            }

            if ($nota < 0 || $nota > 10) {
                throw new \InvalidArgumentException('La nota debe estar entre 0 y 10');
            }

            // Verificar que la nota existe y pertenece a una materia del profesor
            $notaActual = $this->notaRepository->obtenerPorId($id);
            if (!$notaActual) {
                throw new \RuntimeException('Nota no encontrada');
            }

            if ($_SESSION['rol'] === 'profesor' && !$this->tienePermisoParaMateria($notaActual['materia_id'])) {
                throw new \RuntimeException('No tienes permisos para editar esta nota');
            }

            if (!$this->notaRepository->actualizar([
                'id' => $id,
                'nota' => $nota,
                'profesor_id' => $_SESSION['user_id'],
                'es_gestor' => $_SESSION['rol'] === 'gestor'
            ])) {
                throw new \RuntimeException('Error al actualizar la nota');
            }

            $this->redirect('/notas/listar', [
                'materia_id' => $notaActual['materia_id'],
                'trimestre' => $notaActual['trimestre'],
                'mensaje' => 'Nota actualizada correctamente'
            ]);

        } catch (\Exception $e) {
            error_log("Error al editar nota: " . $e->getMessage());
            $this->redirect('/notas', ['error' => $e->getMessage()]);
        }
    }

    public function eliminar(): void
    {
        $this->requireRole('gestor', 'profesor');
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/notas');
            return;
        }

        try {
            $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
            
            if ($id <= 0) {
                throw new \InvalidArgumentException('ID de nota inválido');
            }

            // Verificar que la nota existe y pertenece a una materia del profesor
            $nota = $this->notaRepository->obtenerPorId($id);
            if (!$nota) {
                throw new \RuntimeException('Nota no encontrada');
            }

            if ($_SESSION['rol'] === 'profesor' && !$this->tienePermisoParaMateria($nota['materia_id'])) {
                throw new \RuntimeException('No tienes permisos para eliminar esta nota');
            }

            if (!$this->notaRepository->eliminar($id, $_SESSION['user_id'], $_SESSION['rol'] === 'gestor')) {
                throw new \RuntimeException('Error al eliminar la nota');
            }

            $this->redirect('/notas/listar', [
                'materia_id' => $nota['materia_id'],
                'trimestre' => $nota['trimestre'],
                'mensaje' => 'Nota eliminada correctamente'
            ]);

        } catch (\Exception $e) {
            error_log("Error al eliminar nota: " . $e->getMessage());
            $this->redirect('/notas', ['error' => $e->getMessage()]);
        }
    }

    public function generarInforme(): void
    {
        $this->requireRole('gestor', 'profesor', 'alumno');
        
        try {
            $tipo = $_GET['tipo'] ?? '';
            $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

            if (empty($tipo) || $id <= 0) {
                throw new \InvalidArgumentException('Parámetros incorrectos');
            }

            // Verificar permisos según el tipo de informe
            if ($tipo === 'alumno' && !$this->tienePermisoParaVerAlumno($id)) {
                throw new \RuntimeException('No tienes permisos para ver este informe');
            }

            $informeData = match($tipo) {
                'alumno' => $this->notaRepository->obtenerNotasAlumno($id),
                'materia' => $this->notaRepository->obtenerMediasPorMateria($id),
                'alumno_medias' => $this->notaRepository->obtenerMediasPorAlumno($id),
                default => throw new \InvalidArgumentException('Tipo de informe no válido')
            };

            if (empty($informeData)) {
                throw new \RuntimeException('No hay datos para generar el informe');
            }

            $this->render('informes/notas', [
                'tipo' => $tipo,
                'data' => $informeData
            ]);

        } catch (\Exception $e) {
            error_log("Error al generar informe: " . $e->getMessage());
            $this->redirect('/notas', ['error' => $e->getMessage()]);
        }
    }

    public function descargarPDF(): void
    {
        $this->requireRole('gestor', 'profesor', 'alumno');
        
        try {
            $alumnoId = isset($_GET['alumno_id']) ? (int)$_GET['alumno_id'] : 0;
            
            if ($alumnoId <= 0) {
                throw new \InvalidArgumentException('ID de alumno inválido');
            }

            if (!$this->tienePermisoParaVerAlumno($alumnoId)) {
                throw new \RuntimeException('No tienes permisos para ver estas notas');
            }

            $alumno = $this->usuarioRepository->obtenerPorId($alumnoId);
            if (!$alumno) {
                throw new \RuntimeException('Alumno no encontrado');
            }

            $notas = $this->notaRepository->obtenerNotasParaInforme($alumnoId);
            if (empty($notas)) {
                throw new \RuntimeException('No hay notas para generar el informe');
            }

            $nombreArchivo = sprintf(
                'boletin_%s_%s_%s.pdf',
                $alumno['apellido1'],
                $alumno['nombre'],
                date('Y-m-d')
            );

            $pdf = $this->pdfService->generarBoletinNotas($alumno, $notas);

            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $nombreArchivo . '"');
            echo $pdf;
            exit();

        } catch (\Exception $e) {
            error_log("Error al descargar PDF: " . $e->getMessage());
            $this->redirect('/notas', ['error' => $e->getMessage()]);
        }
    }

    private function tienePermisoParaMateria(int $materiaId): bool
    {
        if ($_SESSION['rol'] === 'gestor') {
            return true;
        }

        $materias = $this->materiaRepository->obtenerMateriasPorProfesor($_SESSION['user_id']);
        return !empty(array_filter($materias, fn($m) => $m['id'] === $materiaId));
    }

    private function tienePermisoParaVerAlumno(int $alumnoId): bool
    {
        if ($_SESSION['rol'] === 'gestor') {
            return true;
        }

        if ($_SESSION['rol'] === 'tutor') {
            return $this->usuarioRepository->esTutorDeAlumno($_SESSION['user_id'], $alumnoId);
        }

        if ($_SESSION['rol'] === 'profesor') {
            // Un profesor puede ver las notas de los alumnos en sus materias
            $materias = $this->materiaRepository->obtenerMateriasPorProfesor($_SESSION['user_id']);
            $notasAlumno = $this->notaRepository->obtenerNotasAlumno($alumnoId);
            
            foreach ($notasAlumno as $nota) {
                if (array_filter($materias, fn($m) => $m['id'] === $nota['materia_id'])) {
                    return true;
                }
            }
        }

        return false;
    }
}
