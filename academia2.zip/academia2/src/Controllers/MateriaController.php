<?php

namespace App\Controllers;

use App\Repository\MateriaRepository;
use App\Repository\UsuarioRepository;

class MateriaController extends BaseController
{
    private MateriaRepository $materiaRepository;
    private UsuarioRepository $usuarioRepository;

    public function __construct()
    {
        parent::__construct();
        $this->materiaRepository = new MateriaRepository();
        $this->usuarioRepository = new UsuarioRepository();
    }

    public function index(): void
    {
        $this->requireRole('gestor', 'profesor');
        
        try {
            $materias = ($_SESSION['rol'] === 'profesor')
                ? $this->materiaRepository->obtenerMateriasPorProfesor($_SESSION['user_id'])
                : $this->materiaRepository->listar();

            $this->render('materias/index', ['materias' => $materias]);
        } catch (\Exception $e) {
            error_log("Error al listar materias: " . $e->getMessage());
            $this->redirect('/materias', ['error' => 'Error al cargar las materias']);
        }
    }

    public function nuevaForm(): void
    {
        $this->requireRole('gestor');
        
        try {
            $profesores = $this->usuarioRepository->obtenerProfesores();
            $this->render('materias/nueva', ['profesores' => $profesores]);
        } catch (\Exception $e) {
            error_log("Error al cargar formulario de nueva materia: " . $e->getMessage());
            $this->redirect('/materias', ['error' => 'Error al cargar el formulario']);
        }
    }

    public function crear(): void
    {
        $this->requireRole('gestor');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/materias/nueva');
        }

        try {
            // Validar datos
            $data = $this->getPostData(['nombre', 'descripcion', 'profesores']);
            $errors = $this->validateRequired($data, [
                'nombre' => 'El nombre de la materia es obligatorio'
            ]);

            if (!empty($errors)) {
                $this->render('materias/nueva', [
                    'errores' => $errors,
                    'old' => $data,
                    'profesores' => $this->usuarioRepository->obtenerProfesores()
                ]);
                return;
            }

            // Validar que el nombre no esté duplicado
            if ($this->materiaRepository->existePorNombre($data['nombre'])) {
                $this->render('materias/nueva', [
                    'errores' => ['Ya existe una materia con ese nombre'],
                    'old' => $data,
                    'profesores' => $this->usuarioRepository->obtenerProfesores()
                ]);
                return;
            }

            // Crear materia
            $materiaId = $this->materiaRepository->crear([
                'nombre' => $this->cleanInput($data['nombre']),
                'descripcion' => $this->cleanInput($data['descripcion'] ?? '')
            ]);

            if (!$materiaId) {
                throw new \RuntimeException('Error al crear la materia');
            }

            // Asignar profesores si se han seleccionado
            if (!empty($data['profesores']) && is_array($data['profesores'])) {
                foreach ($data['profesores'] as $profesorId) {
                    if (!$this->materiaRepository->asignarProfesor($materiaId, (int)$profesorId)) {
                        error_log("Error al asignar profesor {$profesorId} a materia {$materiaId}");
                    }
                }
            }

            $this->redirect('/materias', ['mensaje' => 'Materia creada correctamente']);

        } catch (\Exception $e) {
            error_log("Error al crear materia: " . $e->getMessage());
            $this->redirect('/materias/nueva', ['error' => 'Error al crear la materia']);
        }
    }

    public function asignarProfesorForm(int $materiaId): void
    {
        $this->requireRole('gestor');

        try {
            $materia = $this->materiaRepository->obtenerPorId($materiaId);
            if (!$materia) {
                throw new \RuntimeException('Materia no encontrada');
            }

            $profesoresAsignados = $this->materiaRepository->obtenerProfesoresPorMateria($materiaId);
            $todosProfesores = $this->usuarioRepository->obtenerProfesores();

            $this->render('materias/asignar_profesor', [
                'materia' => $materia,
                'profesoresAsignados' => $profesoresAsignados,
                'todosProfesores' => $todosProfesores
            ]);

        } catch (\Exception $e) {
            error_log("Error al cargar formulario de asignación: " . $e->getMessage());
            $this->redirect('/materias', ['error' => 'Error al cargar el formulario de asignación']);
        }
    }

    public function asignarProfesor(): void
    {
        $this->requireRole('gestor');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/materias');
        }

        try {
            $data = $this->getPostData(['materia_id', 'profesor_id']);
            $errors = $this->validateRequired($data, [
                'materia_id' => 'La materia es obligatoria',
                'profesor_id' => 'El profesor es obligatorio'
            ]);

            if (!empty($errors)) {
                $this->redirect("/materias/asignar/{$data['materia_id']}", ['error' => 'Datos inválidos']);
                return;
            }

            $materiaId = (int)$data['materia_id'];
            $profesorId = (int)$data['profesor_id'];

            // Validar que la materia existe
            $materia = $this->materiaRepository->obtenerPorId($materiaId);
            if (!$materia) {
                throw new \RuntimeException('Materia no encontrada');
            }

            // Validar que el profesor existe y es profesor
            $profesor = $this->usuarioRepository->findById($profesorId);
            if (!$profesor || $profesor['rol'] !== 'profesor') {
                throw new \RuntimeException('Profesor no válido');
            }

            // Validar que no esté ya asignado
            if ($this->materiaRepository->profesorEstaAsignado($materiaId, $profesorId)) {
                $this->redirect("/materias/asignar/{$materiaId}", 
                    ['error' => 'El profesor ya está asignado a esta materia']);
                return;
            }

            if (!$this->materiaRepository->asignarProfesor($materiaId, $profesorId)) {
                throw new \RuntimeException('Error al asignar profesor');
            }

            $this->redirect('/materias', ['mensaje' => 'Profesor asignado correctamente']);

        } catch (\Exception $e) {
            error_log("Error al asignar profesor: " . $e->getMessage());
            $this->redirect('/materias', ['error' => 'Error al asignar profesor']);
        }
    }

    public function eliminarProfesor(): void
    {
        $this->requireRole('gestor');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/materias');
        }

        try {
            $data = $this->getPostData(['materia_id', 'profesor_id']);
            $errors = $this->validateRequired($data, [
                'materia_id' => 'La materia es obligatoria',
                'profesor_id' => 'El profesor es obligatorio'
            ]);

            if (!empty($errors)) {
                $this->redirect('/materias', ['error' => 'Datos inválidos']);
                return;
            }

            $materiaId = (int)$data['materia_id'];
            $profesorId = (int)$data['profesor_id'];

            if (!$this->materiaRepository->eliminarProfesor($materiaId, $profesorId)) {
                throw new \RuntimeException('Error al eliminar profesor de la materia');
            }

            $this->redirect('/materias', ['mensaje' => 'Profesor eliminado correctamente']);

        } catch (\Exception $e) {
            error_log("Error al eliminar profesor: " . $e->getMessage());
            $this->redirect('/materias', ['error' => 'Error al eliminar profesor']);
        }
    }
}
