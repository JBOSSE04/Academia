<?php

namespace App\Controllers;

class HomeController extends BaseController
{
    public function index()
    {
        if (!isset($_SESSION['user_id'])) {
            header('Location: /login');
            exit();
        }

        // Redirección por defecto a notas
        header('Location: /notas');
        exit();
    }
}
