<?php

namespace App\Controllers;

class TutorController extends BaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->checkRole(['tutor']);
    }

    public function dashboard(): void
    {
        $this->render('tutores/dashboard', [
            'titulo' => 'Panel de Tutor',
            'usuario' => $_SESSION['user']
        ]);
    }
}
