<?php

namespace App\Controllers;

class AlumnoController extends BaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->checkRole(['alumno']);
    }

    public function dashboard(): void
    {
        $this->render('alumnos/dashboard', [
            'titulo' => 'Panel de Alumno',
            'usuario' => $_SESSION['user']
        ]);
    }
}
