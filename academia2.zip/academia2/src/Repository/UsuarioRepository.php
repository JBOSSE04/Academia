<?php

namespace App\Repository;

use App\Config\Database;
use PDO;
use PDOException;

class UsuarioRepository
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    protected string $table = 'usuarios';

    public function findByUsername(string $username): ?array
    {
        try {
            // Log para depuración
            error_log("Buscando usuario con email: " . $username);
            
            return $this->fetch(
                "SELECT id, nombre, apellido1, apellido2, email, password, dni, tipo_usuario, 
                CASE 
                    WHEN password = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi' THEN 1 
                    ELSE 0 
                END as primer_login
                FROM usuarios 
                WHERE email = :username",
                ['username' => $username]
            );
        } catch (PDOException $e) {
            error_log("Error en findByUsername: " . $e->getMessage());
            return null;
        }
    }

    public function findByEmail(string $email): ?array
    {
        try {
            // Log para depuración
            error_log("Buscando usuario con email: " . $email);
            
            return $this->fetch(
                "SELECT id, nombre, apellido1, apellido2, email, password, dni, tipo_usuario, 
                CASE 
                    WHEN password = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi' THEN 1 
                    ELSE 0 
                END as primer_login
                FROM usuarios 
                WHERE email = :email",
                ['email' => $email]
            );
        } catch (PDOException $e) {
            error_log("Error en findByEmail: " . $e->getMessage());
            return null;
        }
    }

    public function findById(int $id): ?array
    {
        try {
            return $this->fetch(
                "SELECT id, nombre, apellido1, apellido2, email, dni, tipo_usuario 
                FROM usuarios 
                WHERE id = :id",
                ['id' => $id]
            );
        } catch (PDOException $e) {
            error_log("Error en findById: " . $e->getMessage());
            return null;
        }
    }

    public function obtenerPorId(int $id): ?array
    {
        try {
            $stmt = $this->db->prepare("
                SELECT u.*, r.nombre as rol_nombre 
                FROM usuarios u
                JOIN roles r ON u.rol_id = r.id
                WHERE u.id = ?
            ");
            $stmt->execute([$id]);
            
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (PDOException $e) {
            error_log("Error en obtenerPorId: " . $e->getMessage());
            return null;
        }
    }

    public function listarTodos(): array
    {
        try {
            $stmt = $this->db->query("
                SELECT u.*, r.nombre as rol_nombre 
                FROM usuarios u
                JOIN roles r ON u.rol_id = r.id
                ORDER BY u.apellido1, u.apellido2, u.nombre
            ");
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error en listarTodos: " . $e->getMessage());
            return [];
        }
    }

    public function listarAlumnos(): array
    {
        try {
            $stmt = $this->db->prepare("
                SELECT u.*, r.nombre as rol_nombre 
                FROM usuarios u
                JOIN roles r ON u.rol_id = r.id
                WHERE r.nombre = 'alumno'
                ORDER BY u.apellido1, u.apellido2, u.nombre
            ");
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error en listarAlumnos: " . $e->getMessage());
            return [];
        }
    }

    public function obtenerAlumnosDeTutor(int $tutorId): array
    {
        try {
            $stmt = $this->db->prepare("
                SELECT u.*, r.nombre as rol_nombre 
                FROM usuarios u
                JOIN roles r ON u.rol_id = r.id
                JOIN alumnos_tutores at ON u.id = at.alumno_id
                WHERE at.tutor_id = ? AND r.nombre = 'alumno'
                ORDER BY u.apellido1, u.apellido2, u.nombre
            ");
            $stmt->execute([$tutorId]);
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error en obtenerAlumnosDeTutor: " . $e->getMessage());
            return [];
        }
    }

    public function getRoles(): array
    {
        try {
            return $this->fetchAll("SELECT * FROM roles ORDER BY nombre");
        } catch (PDOException $e) {
            error_log("Error en getRoles: " . $e->getMessage());
            return [];
        }
    }

    public function existeDNI(string $dni, ?int $excludeId = null): bool
    {
        try {
            $query = "SELECT COUNT(*) as count FROM {$this->table} WHERE dni = :dni";
            $params = ['dni' => $dni];

            if ($excludeId !== null) {
                $query .= " AND id != :excludeId";
                $params['excludeId'] = $excludeId;
            }

            $result = $this->fetch($query, $params);
            return $result['count'] > 0;
        } catch (PDOException $e) {
            error_log("Error en existeDNI: " . $e->getMessage());
            return false;
        }
    }

    public function existeEmail(string $email, ?int $excludeId = null): bool
    {
        try {
            $query = "SELECT COUNT(*) as count FROM {$this->table} WHERE email = :email";
            $params = ['email' => $email];

            if ($excludeId !== null) {
                $query .= " AND id != :excludeId";
                $params['excludeId'] = $excludeId;
            }

            $result = $this->fetch($query, $params);
            return $result['count'] > 0;
        } catch (PDOException $e) {
            error_log("Error en existeEmail: " . $e->getMessage());
            return false;
        }
    }

    public function actualizarPassword(int $id, string $hashedPassword): bool
    {
        try {
            $sql = "UPDATE usuarios SET password = :password WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([
                'password' => $hashedPassword,
                'id' => $id
            ]);
        } catch (PDOException $e) {
            error_log("Error en actualizarPassword: " . $e->getMessage());
            return false;
        }
    }

    public function findByRole(string $role): array
    {
        try {
            $sql = "SELECT id, nombre, apellido1, apellido2, email, dni 
                    FROM usuarios 
                    WHERE tipo_usuario = :role";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute(['role' => $role]);
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error en findByRole: " . $e->getMessage());
            return [];
        }
    }

    public function crear(array $datos): int
    {
        try {
            $sql = "INSERT INTO usuarios (nombre, apellido1, apellido2, email, password, dni, tipo_usuario) 
                    VALUES (:nombre, :apellido1, :apellido2, :email, :password, :dni, :tipo_usuario)";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                'nombre' => $datos['nombre'],
                'apellido1' => $datos['apellido1'],
                'apellido2' => $datos['apellido2'],
                'email' => $datos['email'],
                'password' => $datos['password'],
                'dni' => $datos['dni'],
                'tipo_usuario' => $datos['tipo_usuario']
            ]);
            return $this->db->lastInsertId();
        } catch (PDOException $e) {
            error_log("Error en crear: " . $e->getMessage());
            return 0;
        }
    }

    public function actualizar(int $id, array $datos): bool
    {
        try {
            $sql = "UPDATE usuarios SET 
                    nombre = :nombre,
                    apellido1 = :apellido1,
                    apellido2 = :apellido2,
                    email = :email,
                    dni = :dni,
                    tipo_usuario = :tipo_usuario
                    WHERE id = :id";
            
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([
                'id' => $id,
                'nombre' => $datos['nombre'],
                'apellido1' => $datos['apellido1'],
                'apellido2' => $datos['apellido2'],
                'email' => $datos['email'],
                'dni' => $datos['dni'],
                'tipo_usuario' => $datos['tipo_usuario']
            ]);
        } catch (PDOException $e) {
            error_log("Error en actualizar: " . $e->getMessage());
            return false;
        }
    }

    public function eliminar(int $id): bool
    {
        try {
            $sql = "DELETE FROM usuarios WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute(['id' => $id]);
        } catch (PDOException $e) {
            error_log("Error en eliminar: " . $e->getMessage());
            return false;
        }
    }

    private function fetch(string $sql, array $params = []): ?array
    {
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (PDOException $e) {
            error_log("Error en fetch: " . $e->getMessage());
            return null;
        }
    }

    private function fetchAll(string $sql, array $params = []): array
    {
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error en fetchAll: " . $e->getMessage());
            return [];
        }
    }
}
