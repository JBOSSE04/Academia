<?php

namespace App\Repository;

use App\Repository\Interfaces\NotaRepositoryInterface;

class NotaRepository extends BaseRepository implements NotaRepositoryInterface
{
    protected string $table = 'notas';

    public function crear(array $datos): bool
    {
        // Verificar si ya existe una nota para este alumno, materia y trimestre
        $notaExistente = $this->fetch(
            "SELECT id FROM notas WHERE alumno_id = ? AND materia_id = ? AND trimestre = ?",
            [$datos['alumno_id'], $datos['materia_id'], $datos['trimestre']]
        );

        if ($notaExistente) {
            return false;
        }

        return $this->executeQuery(
            "INSERT INTO notas (alumno_id, materia_id, trimestre, nota, profesor_id) VALUES (?, ?, ?, ?, ?)",
            [
                $datos['alumno_id'],
                $datos['materia_id'],
                $datos['trimestre'],
                $datos['nota'],
                $datos['profesor_id']
            ]
        );
    }

    public function actualizar(array $datos): bool
    {
        return $this->executeQuery(
            "UPDATE notas SET nota = ? WHERE id = ? AND (profesor_id = ? OR ? = true)",
            [$datos['nota'], $datos['id'], $datos['profesor_id'], $datos['es_gestor']]
        );
    }

    public function eliminar(int $id, int $profesorId, bool $esGestor): bool
    {
        return $this->executeQuery(
            "DELETE FROM notas WHERE id = ? AND (profesor_id = ? OR ? = true)",
            [$id, $profesorId, $esGestor]
        );
    }

    public function obtenerNotasPorMateriaYTrimestre(int $materiaId, int $trimestre): array
    {
        return $this->fetchAll(
            "SELECT n.*, a.nombre, a.apellido1, a.apellido2 
             FROM notas n 
             INNER JOIN alumnos a ON n.alumno_id = a.id 
             WHERE n.materia_id = ? AND n.trimestre = ? 
             ORDER BY a.apellido1, a.apellido2, a.nombre",
            [$materiaId, $trimestre]
        );
    }

    public function obtenerNotasAlumno(int $alumnoId): array
    {
        return $this->fetchAll(
            "SELECT n.*, m.nombre as materia_nombre 
             FROM notas n 
             INNER JOIN materias m ON n.materia_id = m.id 
             WHERE n.alumno_id = ? 
             ORDER BY m.nombre, n.trimestre",
            [$alumnoId]
        );
    }

    public function obtenerMediasPorMateria(int $materiaId): array
    {
        return $this->fetchAll(
            "SELECT a.nombre, a.apellido1, a.apellido2, 
                    AVG(n.nota) as nota_media 
             FROM alumnos a 
             INNER JOIN notas n ON a.id = n.alumno_id 
             WHERE n.materia_id = ? 
             GROUP BY a.id, a.nombre, a.apellido1, a.apellido2 
             ORDER BY a.apellido1, a.apellido2, a.nombre",
            [$materiaId]
        );
    }

    public function obtenerMediasPorAlumno(int $alumnoId): array
    {
        return $this->fetchAll(
            "SELECT m.nombre as materia_nombre, 
                    AVG(n.nota) as nota_media 
             FROM materias m 
             INNER JOIN notas n ON m.id = n.materia_id 
             WHERE n.alumno_id = ? 
             GROUP BY m.id, m.nombre 
             ORDER BY m.nombre",
            [$alumnoId]
        );
    }

    public function obtenerNotasParaInforme(int $alumnoId): array
    {
        return $this->fetchAll(
            "SELECT m.nombre as materia, n.trimestre, n.nota 
             FROM notas n 
             INNER JOIN materias m ON n.materia_id = m.id 
             WHERE n.alumno_id = ? 
             ORDER BY m.nombre, n.trimestre",
            [$alumnoId]
        );
    }

    public function findByAlumno(int $alumnoId): array
    {
        return $this->fetchAll("
            SELECT n.*, m.nombre as materia_nombre, 
                   CONCAT(u.nombre, ' ', u.apellido1, ' ', u.apellido2) as profesor_nombre
            FROM {$this->table} n
            JOIN materias m ON n.materia_id = m.id
            JOIN usuarios u ON m.profesor_id = u.id
            WHERE n.alumno_id = :alumno_id
            ORDER BY m.nombre, n.fecha DESC
        ", ['alumno_id' => $alumnoId]);
    }

    public function findByMateria(int $materiaId): array
    {
        return $this->fetchAll("
            SELECT n.*, 
                   CONCAT(u.nombre, ' ', u.apellido1, ' ', u.apellido2) as alumno_nombre
            FROM {$this->table} n
            JOIN usuarios u ON n.alumno_id = u.id
            WHERE n.materia_id = :materia_id
            ORDER BY u.apellido1, u.apellido2, u.nombre, n.fecha DESC
        ", ['materia_id' => $materiaId]);
    }

    public function getPromedioByAlumno(int $alumnoId): float
    {
        $result = $this->fetch("
            SELECT AVG(valor) as promedio
            FROM {$this->table}
            WHERE alumno_id = :alumno_id
        ", ['alumno_id' => $alumnoId]);

        return $result ? (float)$result['promedio'] : 0.0;
    }

    public function getEstadisticasByMateria(int $materiaId): array
    {
        return $this->fetch("
            SELECT 
                COUNT(*) as total_notas,
                AVG(valor) as promedio,
                MIN(valor) as minima,
                MAX(valor) as maxima
            FROM {$this->table}
            WHERE materia_id = :materia_id
        ", ['materia_id' => $materiaId]) ?? [
            'total_notas' => 0,
            'promedio' => 0,
            'minima' => 0,
            'maxima' => 0
        ];
    }

    public function getNotasWithDetails(int $alumnoId): array
    {
        return $this->fetchAll("
            SELECT n.*,
                   m.nombre as materia_nombre,
                   CONCAT(u.nombre, ' ', u.apellido1, ' ', u.apellido2) as profesor_nombre
            FROM {$this->table} n
            JOIN materias m ON n.materia_id = m.id
            JOIN usuarios u ON m.profesor_id = u.id
            WHERE n.alumno_id = :alumno_id
            ORDER BY n.fecha DESC, m.nombre
        ", ['alumno_id' => $alumnoId]);
    }

    public function getNotasByFecha(string $fechaInicio, string $fechaFin): array
    {
        return $this->fetchAll("
            SELECT n.*,
                   m.nombre as materia_nombre,
                   CONCAT(a.nombre, ' ', a.apellido1, ' ', a.apellido2) as alumno_nombre,
                   CONCAT(p.nombre, ' ', p.apellido1, ' ', p.apellido2) as profesor_nombre
            FROM {$this->table} n
            JOIN materias m ON n.materia_id = m.id
            JOIN usuarios a ON n.alumno_id = a.id
            JOIN usuarios p ON m.profesor_id = p.id
            WHERE n.fecha BETWEEN :fecha_inicio AND :fecha_fin
            ORDER BY n.fecha DESC, m.nombre, alumno_nombre
        ", [
            'fecha_inicio' => $fechaInicio,
            'fecha_fin' => $fechaFin
        ]);
    }

    public function obtenerPromediosAlumno(int $alumnoId): array
    {
        return $this->fetchAll("
            SELECT 
                m.nombre as materia_nombre,
                AVG(n.nota) as promedio,
                COUNT(n.id) as total_notas,
                MIN(n.nota) as nota_minima,
                MAX(n.nota) as nota_maxima
            FROM materias m
            LEFT JOIN notas n ON m.id = n.materia_id AND n.alumno_id = :alumno_id
            WHERE EXISTS (
                SELECT 1 
                FROM matriculas mt 
                WHERE mt.alumno_id = :alumno_id 
                AND mt.materia_id = m.id
            )
            GROUP BY m.id, m.nombre
            ORDER BY m.nombre
        ", ['alumno_id' => $alumnoId]);
    }

    public function obtenerPorId(int $id): ?array
    {
        return $this->fetch("
            SELECT n.*, m.nombre as materia_nombre 
            FROM {$this->table} n
            JOIN materias m ON n.materia_id = m.id
            WHERE n.id = :id
        ", ['id' => $id]);
    }
}
