<?php

namespace App\Repository;

use App\Config\Database;
use App\Repository\Interfaces\RepositoryInterface;
use PDO;

abstract class BaseRepository implements RepositoryInterface
{
    protected PDO $db;
    protected string $table;
    protected string $primaryKey = 'id';

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    public function findById(int $id): ?array
    {
        return $this->fetch(
            "SELECT * FROM {$this->table} WHERE {$this->primaryKey} = :id",
            ['id' => $id]
        );
    }

    public function findAll(): array
    {
        return $this->fetchAll("SELECT * FROM {$this->table}");
    }

    public function create(array $data): int
    {
        $fields = array_keys($data);
        $placeholders = array_map(fn($field) => ":$field", $fields);
        
        $query = sprintf(
            "INSERT INTO %s (%s) VALUES (%s)",
            $this->table,
            implode(', ', $fields),
            implode(', ', $placeholders)
        );

        $this->executeQuery($query, $data);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id, array $data): bool
    {
        $fields = array_map(
            fn($field) => "$field = :$field",
            array_keys($data)
        );
        
        $query = sprintf(
            "UPDATE %s SET %s WHERE %s = :id",
            $this->table,
            implode(', ', $fields),
            $this->primaryKey
        );

        return $this->executeQuery($query, array_merge($data, ['id' => $id]));
    }

    public function delete(int $id): bool
    {
        return $this->executeQuery(
            "DELETE FROM {$this->table} WHERE {$this->primaryKey} = :id",
            ['id' => $id]
        );
    }

    protected function executeQuery(string $query, array $params = []): bool
    {
        $stmt = $this->db->prepare($query);
        return $stmt->execute($params);
    }

    protected function fetch(string $query, array $params = []): ?array
    {
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ?: null;
    }

    protected function fetchAll(string $query, array $params = []): array
    {
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
