<?php

namespace App\Repository\Interfaces;

interface MateriaRepositoryInterface extends RepositoryInterface
{
    public function findByNombre(string $nombre): ?array;
    public function getMateriasWithStats(): array;
    public function getMateriasByProfesor(int $profesorId): array;
}
