<?php

namespace App\Repository\Interfaces;

interface NotaRepositoryInterface extends RepositoryInterface
{
    public function findByAlumno(int $alumnoId): array;
    public function findByMateria(int $materiaId): array;
    public function getPromedioByAlumno(int $alumnoId): float;
    public function getEstadisticasByMateria(int $materiaId): array;
    public function getNotasWithDetails(int $alumnoId): array;
}
