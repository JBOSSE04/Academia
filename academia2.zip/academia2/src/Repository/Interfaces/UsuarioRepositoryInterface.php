<?php

namespace App\Repository\Interfaces;

interface UsuarioRepositoryInterface extends RepositoryInterface
{
    public function findByUsername(string $username): ?array;
    public function findByEmail(string $email): ?array;
    public function existeDNI(string $dni, ?int $excludeId = null): bool;
    public function existeEmail(string $email, ?int $excludeId = null): bool;
    public function getRoles(): array;
    public function actualizarPassword(int $id, string $hashedPassword): bool;
}
