<?php

namespace App\Repository;

use App\Repository\Interfaces\MateriaRepositoryInterface;

class MateriaRepository extends BaseRepository implements MateriaRepositoryInterface
{
    protected string $table = 'materias';

    public function crear(array $datos): bool
    {
        return $this->executeQuery(
            "INSERT INTO materias (nombre, descripcion) VALUES (?, ?)",
            [$datos['nombre'], $datos['descripcion']]
        );
    }

    public function listar(): array
    {
        return $this->fetchAll("SELECT * FROM materias ORDER BY nombre");
    }

    public function obtenerPorId(int $id): ?array
    {
        return $this->fetch(
            "SELECT * FROM materias WHERE id = ?",
            [$id]
        );
    }

    public function obtenerMateriasPorProfesor(int $profesorId): array
    {
        return $this->fetchAll(
            "SELECT m.* FROM materias m 
             INNER JOIN profesor_materia pm ON m.id = pm.materia_id 
             WHERE pm.profesor_id = ?",
            [$profesorId]
        );
    }

    public function asignarProfesor(int $materiaId, int $profesorId): bool
    {
        return $this->executeQuery(
            "INSERT INTO profesor_materia (profesor_id, materia_id) VALUES (?, ?)",
            [$profesorId, $materiaId]
        );
    }

    public function desasignarProfesor(int $materiaId, int $profesorId): bool
    {
        return $this->executeQuery(
            "DELETE FROM profesor_materia WHERE profesor_id = ? AND materia_id = ?",
            [$profesorId, $materiaId]
        );
    }

    public function obtenerProfesoresPorMateria(int $materiaId): array
    {
        return $this->fetchAll(
            "SELECT u.* FROM usuarios u 
             INNER JOIN profesor_materia pm ON u.id = pm.profesor_id 
             WHERE pm.materia_id = ? AND u.rol_id = (SELECT id FROM roles WHERE nombre = 'profesor')",
            [$materiaId]
        );
    }

    public function findByNombre(string $nombre): ?array
    {
        return $this->fetch(
            "SELECT * FROM {$this->table} WHERE nombre = :nombre",
            ['nombre' => $nombre]
        );
    }

    public function getMateriasWithStats(): array
    {
        return $this->fetchAll("
            SELECT m.*,
                   CONCAT(u.nombre, ' ', u.apellido1, ' ', u.apellido2) as profesor_nombre,
                   COUNT(DISTINCT n.alumno_id) as total_alumnos,
                   COUNT(n.id) as total_notas,
                   COALESCE(AVG(n.valor), 0) as promedio
            FROM {$this->table} m
            JOIN usuarios u ON m.profesor_id = u.id
            LEFT JOIN notas n ON m.id = n.materia_id
            GROUP BY m.id, m.nombre, m.profesor_id, profesor_nombre
            ORDER BY m.nombre
        ");
    }

    public function getMateriasByProfesor(int $profesorId): array
    {
        return $this->fetchAll("
            SELECT m.*,
                   COUNT(DISTINCT n.alumno_id) as total_alumnos,
                   COUNT(n.id) as total_notas,
                   COALESCE(AVG(n.valor), 0) as promedio
            FROM {$this->table} m
            LEFT JOIN notas n ON m.id = n.materia_id
            WHERE m.profesor_id = :profesor_id
            GROUP BY m.id, m.nombre
            ORDER BY m.nombre
        ", ['profesor_id' => $profesorId]);
    }

    public function findAll(): array
    {
        return $this->fetchAll("
            SELECT m.*, CONCAT(u.nombre, ' ', u.apellido1, ' ', u.apellido2) as profesor_nombre
            FROM {$this->table} m
            JOIN usuarios u ON m.profesor_id = u.id
            ORDER BY m.nombre
        ");
    }
}
