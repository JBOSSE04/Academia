<?php require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6 text-center">
            <h1 class="display-1">500</h1>
            <h2>Error del servidor</h2>
            <p class="lead">Lo sentimos, ha ocurrido un error en el servidor.</p>
            <a href="/" class="btn btn-primary">Volver al inicio</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
