<?php require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="mb-0">
            <?php
            switch ($tipo) {
                case 'alumno':
                    echo 'Listado Completo de Notas del Alumno';
                    break;
                case 'materia':
                    echo 'Notas Medias por Asignatura';
                    break;
                case 'alumno_medias':
                    echo 'Notas Medias por Alumno';
                    break;
            }
            ?>
        </h3>
        <?php if ($tipo === 'alumno'): ?>
            <a href="/informes/descargar-pdf.php?alumno_id=<?php echo $_GET['id']; ?>" 
               class="btn btn-primary">
                Descargar PDF
            </a>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <?php switch ($tipo):
                            case 'alumno': ?>
                                <th>Asignatura</th>
                                <th>Trimestre</th>
                                <th>Nota</th>
                                <?php break;
                            case 'materia': ?>
                                <th>Alumno</th>
                                <th>Nota Media</th>
                                <?php break;
                            case 'alumno_medias': ?>
                                <th>Asignatura</th>
                                <th>Nota Media</th>
                                <?php break;
                        endswitch; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($data as $row): ?>
                        <tr>
                            <?php switch ($tipo):
                                case 'alumno': ?>
                                    <td><?php echo htmlspecialchars($row['materia_nombre']); ?></td>
                                    <td><?php echo htmlspecialchars($row['trimestre']); ?></td>
                                    <td><?php echo number_format($row['nota'], 2); ?></td>
                                    <?php break;
                                case 'materia': ?>
                                    <td><?php echo htmlspecialchars($row['apellido1'] . ' ' . 
                                                                  $row['apellido2'] . ', ' . 
                                                                  $row['nombre']); ?></td>
                                    <td><?php echo number_format($row['nota_media'], 2); ?></td>
                                    <?php break;
                                case 'alumno_medias': ?>
                                    <td><?php echo htmlspecialchars($row['materia_nombre']); ?></td>
                                    <td><?php echo number_format($row['nota_media'], 2); ?></td>
                                    <?php break;
                            endswitch; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
