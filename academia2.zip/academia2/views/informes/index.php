<?php require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card">
    <div class="card-header">
        <h3>Informes</h3>
    </div>
    <div class="card-body">
        <div class="row">
            <!-- Listado de notas por materia y trimestre -->
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-header">
                        <h5>Listado de Notas por Materia y Trimestre</h5>
                    </div>
                    <div class="card-body">
                        <form method="GET" action="/informes/ver.php">
                            <input type="hidden" name="tipo" value="materia_trimestre">
                            <div class="mb-3">
                                <label for="materia_id" class="form-label">Materia</label>
                                <select class="form-select" id="materia_id" name="materia_id" required>
                                    <option value="">Seleccione una materia</option>
                                    <?php foreach ($materias as $materia): ?>
                                        <option value="<?php echo $materia['id']; ?>">
                                            <?php echo htmlspecialchars($materia['nombre']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="trimestre" class="form-label">Trimestre</label>
                                <select class="form-select" id="trimestre" name="trimestre" required>
                                    <option value="">Seleccione un trimestre</option>
                                    <option value="1">Primer Trimestre</option>
                                    <option value="2">Segundo Trimestre</option>
                                    <option value="3">Tercer Trimestre</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Generar Informe</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Listado completo de notas de un alumno -->
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-header">
                        <h5>Listado Completo de Notas por Alumno</h5>
                    </div>
                    <div class="card-body">
                        <form method="GET" action="/informes/ver.php">
                            <input type="hidden" name="tipo" value="alumno">
                            <div class="mb-3">
                                <label for="alumno_id" class="form-label">Alumno</label>
                                <select class="form-select" id="alumno_id" name="id" required>
                                    <option value="">Seleccione un alumno</option>
                                    <?php foreach ($alumnos as $alumno): ?>
                                        <option value="<?php echo $alumno['id']; ?>">
                                            <?php echo htmlspecialchars($alumno['apellido1'] . ' ' . 
                                                                      $alumno['apellido2'] . ', ' . 
                                                                      $alumno['nombre']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Generar Informe</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Listado notas medias por asignatura -->
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-header">
                        <h5>Notas Medias por Asignatura</h5>
                    </div>
                    <div class="card-body">
                        <form method="GET" action="/informes/ver.php">
                            <input type="hidden" name="tipo" value="materia">
                            <div class="mb-3">
                                <label for="materia_id_media" class="form-label">Materia</label>
                                <select class="form-select" id="materia_id_media" name="id" required>
                                    <option value="">Seleccione una materia</option>
                                    <?php foreach ($materias as $materia): ?>
                                        <option value="<?php echo $materia['id']; ?>">
                                            <?php echo htmlspecialchars($materia['nombre']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Generar Informe</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Listado notas medias por alumno -->
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-header">
                        <h5>Notas Medias por Alumno</h5>
                    </div>
                    <div class="card-body">
                        <form method="GET" action="/informes/ver.php">
                            <input type="hidden" name="tipo" value="alumno_medias">
                            <div class="mb-3">
                                <label for="alumno_id_media" class="form-label">Alumno</label>
                                <select class="form-select" id="alumno_id_media" name="id" required>
                                    <option value="">Seleccione un alumno</option>
                                    <?php foreach ($alumnos as $alumno): ?>
                                        <option value="<?php echo $alumno['id']; ?>">
                                            <?php echo htmlspecialchars($alumno['apellido1'] . ' ' . 
                                                                      $alumno['apellido2'] . ', ' . 
                                                                      $alumno['nombre']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Generar Informe</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
