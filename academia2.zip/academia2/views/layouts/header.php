<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title ?? 'Academia Los Excelentes'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/styles.css">
</head>
<body>
    <?php if (isset($_SESSION['user_id'])): ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="/dashboard.php">Academia Los Excelentes</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <?php if ($_SESSION['rol'] === 'gestor'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/usuarios/registro.php">Registrar Usuario</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/materias/nueva.php">Nueva Materia</a>
                        </li>
                    <?php endif; ?>
                    
                    <?php if (in_array($_SESSION['rol'], ['gestor', 'profesor'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/notas/gestionar.php">Gestionar Notas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/informes/index.php">Informes</a>
                        </li>
                    <?php endif; ?>
                    
                    <?php if ($_SESSION['rol'] === 'tutor'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/notas/consulta.php">Consultar Notas</a>
                        </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <span class="nav-link">
                            <?php echo htmlspecialchars($_SESSION['username']); ?>
                            (<?php echo htmlspecialchars($_SESSION['rol']); ?>)
                        </span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/logout.php">Cerrar Sesión</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <?php endif; ?>
    
    <div class="container mt-4">
