<?php require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card">
    <div class="card-header">
        <h3>Gestión de Notas</h3>
    </div>
    <div class="card-body">
        <?php if (!empty($errores)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errores as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="GET" action="/notas/listar.php" class="mb-4">
            <div class="row">
                <div class="col-md-5">
                    <label for="materia_id" class="form-label">Materia</label>
                    <select class="form-select" id="materia_id" name="materia_id" required>
                        <option value="">Seleccione una materia</option>
                        <?php foreach ($materias as $materia): ?>
                            <option value="<?php echo $materia['id']; ?>">
                                <?php echo htmlspecialchars($materia['nombre']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-5">
                    <label for="trimestre" class="form-label">Trimestre</label>
                    <select class="form-select" id="trimestre" name="trimestre" required>
                        <option value="">Seleccione un trimestre</option>
                        <option value="1">Primer Trimestre</option>
                        <option value="2">Segundo Trimestre</option>
                        <option value="3">Tercer Trimestre</option>
                    </select>
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">Ver Notas</button>
                </div>
            </div>
        </form>

        <?php if ($_SESSION['rol'] === 'gestor'): ?>
        <div class="mt-4">
            <h4>Informes Disponibles</h4>
            <div class="list-group">
                <a href="/informes/index.php" class="list-group-item list-group-item-action">
                    <i class="bi bi-file-earmark-text"></i> Ver todos los informes disponibles
                </a>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
