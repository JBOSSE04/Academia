<?php require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="mb-0">
            Notas de <?php echo htmlspecialchars($materia['nombre']); ?> - 
            <?php echo $trimestre; ?>º Trimestre
        </h3>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#agregarNotaModal">
            Agregar Nota
        </button>
    </div>
    <div class="card-body">
        <?php if (isset($_GET['mensaje'])): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($_GET['mensaje']); ?>
            </div>
        <?php endif; ?>

        <?php if (empty($notas)): ?>
            <div class="alert alert-info">
                No hay notas registradas para esta materia y trimestre.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Alumno</th>
                            <th>Nota</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($notas as $nota): ?>
                            <tr>
                                <td>
                                    <?php echo htmlspecialchars($nota['apellido1'] . ' ' . 
                                                              $nota['apellido2'] . ', ' . 
                                                              $nota['nombre']); ?>
                                </td>
                                <td><?php echo number_format($nota['nota'], 2); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-warning editar-nota" 
                                            data-id="<?php echo $nota['id']; ?>"
                                            data-nota="<?php echo $nota['nota']; ?>"
                                            data-bs-toggle="modal" data-bs-target="#editarNotaModal">
                                        Editar
                                    </button>
                                    <button type="button" class="btn btn-sm btn-danger eliminar-nota"
                                            data-id="<?php echo $nota['id']; ?>"
                                            data-bs-toggle="modal" data-bs-target="#eliminarNotaModal">
                                        Eliminar
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal Agregar Nota -->
<div class="modal fade" id="agregarNotaModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Agregar Nota</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="/notas/agregar.php">
                <div class="modal-body">
                    <input type="hidden" name="materia_id" value="<?php echo $materia['id']; ?>">
                    <input type="hidden" name="trimestre" value="<?php echo $trimestre; ?>">
                    
                    <div class="mb-3">
                        <label for="alumno_id" class="form-label">Alumno</label>
                        <select class="form-select" id="alumno_id" name="alumno_id" required>
                            <option value="">Seleccione un alumno</option>
                            <?php foreach ($alumnos as $alumno): ?>
                                <option value="<?php echo $alumno['id']; ?>">
                                    <?php echo htmlspecialchars($alumno['apellido1'] . ' ' . 
                                                              $alumno['apellido2'] . ', ' . 
                                                              $alumno['nombre']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="nota" class="form-label">Nota</label>
                        <input type="number" class="form-control" id="nota" name="nota" 
                               min="0" max="10" step="0.01" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Editar Nota -->
<div class="modal fade" id="editarNotaModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Editar Nota</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="/notas/editar.php">
                <div class="modal-body">
                    <input type="hidden" name="id" id="editar_nota_id">
                    <div class="mb-3">
                        <label for="editar_nota" class="form-label">Nota</label>
                        <input type="number" class="form-control" id="editar_nota" name="nota" 
                               min="0" max="10" step="0.01" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Eliminar Nota -->
<div class="modal fade" id="eliminarNotaModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Eliminar Nota</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                ¿Está seguro de que desea eliminar esta nota?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <form method="POST" action="/notas/eliminar.php" style="display: inline;">
                    <input type="hidden" name="id" id="eliminar_nota_id">
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Configurar modal de editar nota
    document.querySelectorAll('.editar-nota').forEach(function(button) {
        button.addEventListener('click', function() {
            document.getElementById('editar_nota_id').value = this.dataset.id;
            document.getElementById('editar_nota').value = this.dataset.nota;
        });
    });

    // Configurar modal de eliminar nota
    document.querySelectorAll('.eliminar-nota').forEach(function(button) {
        button.addEventListener('click', function() {
            document.getElementById('eliminar_nota_id').value = this.dataset.id;
        });
    });
});
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
