<?php require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="mb-0">Materias</h3>
        <?php if ($_SESSION['rol'] === 'gestor'): ?>
            <a href="/materias/nueva.php" class="btn btn-primary">Nueva Materia</a>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <?php if (isset($_GET['mensaje'])): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($_GET['mensaje']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($_GET['error']); ?>
            </div>
        <?php endif; ?>

        <?php if (empty($materias)): ?>
            <div class="alert alert-info">
                No hay materias registradas.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <?php if ($_SESSION['rol'] === 'gestor'): ?>
                                <th>Acciones</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($materias as $materia): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($materia['nombre']); ?></td>
                                <td><?php echo htmlspecialchars($materia['descripcion'] ?? ''); ?></td>
                                <?php if ($_SESSION['rol'] === 'gestor'): ?>
                                    <td>
                                        <a href="/materias/asignar-profesor.php?id=<?php echo $materia['id']; ?>" 
                                           class="btn btn-sm btn-info">
                                            Asignar Profesor
                                        </a>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
