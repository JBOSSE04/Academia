# Sistema de Gestión Académica

Proyecto desarrollado por Jose Juan para la asignatura de Desarrollo Web en Entorno Servidor.
Profesora: Belén

## Descripción del Proyecto

Este sistema de gestión académica permite administrar una academia educativa, incluyendo la gestión de alumnos, profesores, tutores, materias y calificaciones. El sistema implementa un control de acceso basado en roles y permite diferentes funcionalidades según el tipo de usuario.

## Requisitos del Sistema

- PHP 8.0 o superior
- MySQL 5.7 o superior
- Composer
- Servidor web (Apache/Nginx) o PHP Built-in Server

## Pasos para la profesora:

1. Descomprimir el proyecto
2. Ejecutar: composer install
3. Copiar .env.example a .env
4. Ejecutar: php database/import.php
5. Iniciar servidor: php -S localhost:8000 -t public
6. Acceder a: http://localhost:8000

## Estructura del Proyecto

```
academia2/
├── database/               # Scripts SQL y utilidades de base de datos
├── public/                # Punto de entrada y archivos públicos
│   ├── assets/           # Recursos estáticos (CSS, JS, imágenes)
│   ├── views/            # Vistas de la aplicación
│   └── index.php         # Punto de entrada principal
├── src/                   # Código fuente de la aplicación
│   ├── Config/           # Configuración de la aplicación
│   ├── Controllers/      # Controladores
│   ├── Models/           # Modelos
│   ├── Repository/       # Repositorios para acceso a datos
│   └── Services/         # Servicios de la aplicación
└── vendor/                # Dependencias (gestionado por Composer)
```

## Funcionalidades por Rol

### Administrador
- Gestión completa de usuarios (CRUD)
- Gestión de materias
- Asignación de profesores a materias
- Asignación de tutores a alumnos
- Visualización de todas las calificaciones

### Profesor
- Gestión de calificaciones para sus materias
- Visualización de alumnos en sus materias
- Consulta de información académica

### Tutor
- Seguimiento de alumnos asignados
- Visualización de calificaciones de sus alumnos
- Comunicación con profesores

### Alumno
- Consulta de calificaciones
- Visualización de materias matriculadas
- Acceso a información académica personal

## Credenciales de Prueba

### Administrador
- Email: admin@academia.com
- Contraseña: password

### Profesor
- Email: juan.garcia@academia.com
- Contraseña: password

### Tutor
- Email: carlos.rodriguez@academia.com
- Contraseña: password

### Alumno
- Email: pedro.sanchez@academia.com
- Contraseña: password

## Base de Datos

El sistema utiliza una base de datos MySQL con las siguientes tablas principales:
- usuarios
- materias
- profesor_materia
- tutor_alumno
- notas

El script completo de la base de datos se encuentra en `database/academia_updated.sql`.

## Tecnologías Utilizadas

- PHP 8.0
- MySQL
- Composer para gestión de dependencias
- Bootstrap 5 para el frontend
- PDO para acceso a base de datos

## Características de Seguridad

- Autenticación basada en sesiones
- Control de acceso basado en roles
- Protección contra SQL Injection
- Contraseñas hasheadas
- Validación de formularios
- Protección CSRF

## Contacto

Jose Juan
jjcm2004.2015@gmail.com
