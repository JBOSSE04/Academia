<?php

require_once __DIR__ . '/../vendor/autoload.php';

use App\Controllers\AuthController;
use App\Controllers\AdminController;
use App\Controllers\ProfesorController;
use App\Controllers\TutorController;
use App\Controllers\AlumnoController;
use App\Config\Session;

// Cargar variables de entorno
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/..');
$dotenv->load();

// Iniciar sesión
$session = new Session();

// Obtener la ruta actual
$requestUri = $_SERVER['REQUEST_URI'];
$basePath = '/';  // Ajusta esto según tu configuración
$path = str_replace($basePath, '', $requestUri);
$path = parse_url($path, PHP_URL_PATH);

// Log para depuración
error_log("Ruta solicitada: " . $path);

// Rutas públicas (no requieren autenticación)
$publicRoutes = ['/login', '/logout', '/'];

// Verificar si la ruta requiere autenticación
if (!in_array($path, $publicRoutes) && !$session->get('user_id')) {
    error_log("Redirigiendo a login - Usuario no autenticado");
    header('Location: /login');
    exit;
}

// Rutas y sus controladores correspondientes
$routes = [
    '/' => ['App\Controllers\AuthController', 'loginForm'],
    '/login' => ['App\Controllers\AuthController', 'loginForm'],
    '/auth/login' => ['App\Controllers\AuthController', 'login'],
    '/logout' => ['App\Controllers\AuthController', 'logout'],
    '/cambiar-password' => ['App\Controllers\AuthController', 'cambiarPasswordForm'],
    '/auth/cambiar-password' => ['App\Controllers\AuthController', 'cambiarPassword'],
    '/admin/dashboard' => ['App\Controllers\AdminController', 'dashboard'],
    '/profesores/dashboard' => ['App\Controllers\ProfesorController', 'dashboard'],
    '/tutores/dashboard' => ['App\Controllers\TutorController', 'dashboard'],
    '/alumnos/dashboard' => ['App\Controllers\AlumnoController', 'dashboard']
];

// Manejar la ruta
if (isset($routes[$path])) {
    [$controllerClass, $method] = $routes[$path];
    $controller = new $controllerClass();
    $controller->$method();
} else {
    // Ruta no encontrada
    error_log("Ruta no encontrada: " . $path);
    http_response_code(404);
    require __DIR__ . '/views/404.php';
}
