<?php
require_once __DIR__ . '/../vendor/autoload.php';

use App\Services\AuthService;
session_start();

// Redirigir si no hay sesión o no es primer login
if (!isset($_SESSION['user_id']) || !$_SESSION['primer_login']) {
    header('Location: /login.php');
    exit();
}

$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $authService = new AuthService();
    
    if (empty($_POST['password']) || empty($_POST['password_confirmation'])) {
        $error = 'Todos los campos son obligatorios';
    } elseif ($_POST['password'] !== $_POST['password_confirmation']) {
        $error = 'Las contraseñas no coinciden';
    } elseif (strlen($_POST['password']) < 8) {
        $error = 'La contraseña debe tener al menos 8 caracteres';
    } else {
        if ($authService->actualizarPassword($_SESSION['user_id'], $_POST['password'])) {
            $_SESSION['primer_login'] = false;
            header('Location: /dashboard.php?mensaje=Contraseña actualizada correctamente');
            exit();
        } else {
            $error = 'Error al actualizar la contraseña';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cambiar Contraseña - Academia Los Excelentes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Cambiar Contraseña</h3>
                    </div>
                    <div class="card-body">
                        <p class="alert alert-info">
                            Por seguridad, debes cambiar tu contraseña antes de continuar.
                        </p>
                        
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                        <?php endif; ?>

                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="password" class="form-label">Nueva Contraseña</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="password_confirmation" class="form-label">Confirmar Contraseña</label>
                                <input type="password" class="form-control" id="password_confirmation" 
                                       name="password_confirmation" required>
                            </div>

                            <button type="submit" class="btn btn-primary w-100">Cambiar Contraseña</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
