<?php
require_once __DIR__ . '/../../vendor/autoload.php';

use App\Controllers\MateriaController;

session_start();

$controller = new MateriaController();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller->crear();
} else {
    $controller->nuevaForm();
}
