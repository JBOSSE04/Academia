<?php
require_once __DIR__ . '/../vendor/autoload.php';

use App\Services\AuthService;

session_start();

$error = '';
$errors = [];
$old = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $authService = new AuthService();
    $usuario = $authService->login($_POST['username'], $_POST['password']);

    if ($usuario) {
        $_SESSION['user_id'] = $usuario['id'];
        $_SESSION['username'] = $usuario['username'];
        $_SESSION['rol'] = $usuario['rol_nombre'];
        $_SESSION['primer_login'] = $usuario['primer_login'];

        if ($usuario['primer_login']) {
            header('Location: /cambiar-password.php');
        } else {
            switch ($usuario['rol_nombre']) {
                case 'administrador':
                    header('Location: /admin/dashboard');
                    break;
                case 'profesor':
                    header('Location: /profesores/dashboard');
                    break;
                case 'tutor':
                    header('Location: /tutores/dashboard');
                    break;
                case 'alumno':
                    header('Location: /alumnos/dashboard');
                    break;
                default:
                    header('Location: /');
            }
        }
        exit();
    } else {
        $error = 'Usuario o contraseña incorrectos';
    }
}

if (isset($_SESSION['user_id'])) {
    $rol = $_SESSION['rol'];
    switch ($rol) {
        case 'administrador':
            header('Location: /admin/dashboard');
            break;
        case 'profesor':
            header('Location: /profesores/dashboard');
            break;
        case 'tutor':
            header('Location: /tutores/dashboard');
            break;
        case 'alumno':
            header('Location: /alumnos/dashboard');
            break;
        default:
            header('Location: /');
    }
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Academia Los Excelentes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Iniciar Sesión</h3>
                    </div>
                    <div class="card-body">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger">
                                <?php echo htmlspecialchars($error); ?>
                            </div>
                        <?php endif; ?>

                        <?php if (isset($errors) && !empty($errors)): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0">
                                    <?php foreach ($errors as $error): ?>
                                        <li><?php echo htmlspecialchars($error); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form action="/login" method="POST">
                            <div class="mb-3">
                                <label for="username" class="form-label">Email</label>
                                <input type="email" class="form-control" id="username" name="username" 
                                       value="<?php echo isset($old['username']) ? htmlspecialchars($old['username']) : ''; ?>" 
                                       required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Contraseña</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Iniciar Sesión</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
