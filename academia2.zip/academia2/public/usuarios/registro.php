<?php
require_once __DIR__ . '/../../vendor/autoload.php';

use App\Controllers\UsuarioController;

session_start();

$controller = new UsuarioController();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller->registrar();
} else {
    $controller->registroForm();
}
