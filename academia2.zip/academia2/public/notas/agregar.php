<?php
require_once __DIR__ . '/../../vendor/autoload.php';

use App\Controllers\NotaController;

session_start();

$controller = new NotaController();
$controller->crear();
