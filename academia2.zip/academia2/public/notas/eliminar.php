<?php
require_once __DIR__ . '/../../vendor/autoload.php';

use App\Controllers\NotaController;

session_start();

$controller = new NotaController();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller->eliminar();
} else {
    header('Location: /notas/gestionar.php');
    exit();
}
