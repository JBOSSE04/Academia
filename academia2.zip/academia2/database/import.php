<?php

// Cargar el autoloader de Composer
require_once __DIR__ . '/../vendor/autoload.php';

// Cargar variables de entorno
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/..');
$dotenv->load();

try {
    // Conectar a MySQL sin seleccionar una base de datos
    $pdo = new PDO(
        "mysql:host=" . ($_ENV['DB_HOST'] ?? 'localhost'),
        $_ENV['DB_USER'] ?? 'root',
        $_ENV['DB_PASS'] ?? '',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    echo "Conectado a MySQL correctamente.\n";

    // Leer y ejecutar el archivo SQL
    $sql = file_get_contents(__DIR__ . '/academia_updated.sql');
    
    // Ejecutar múltiples consultas
    $statements = explode(';', $sql);
    foreach ($statements as $statement) {
        if (trim($statement) != '') {
            try {
                $pdo->exec($statement);
                echo "Consulta ejecutada correctamente.\n";
            } catch (PDOException $e) {
                echo "Error en consulta: " . $e->getMessage() . "\n";
                // Continuar con la siguiente consulta
                continue;
            }
        }
    }

    echo "Base de datos creada e importada correctamente.\n";
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage() . "\n");
}
