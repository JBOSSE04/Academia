-- Eliminar la base de datos si existe
DROP DATABASE IF EXISTS academia;

-- Crear la base de datos
CREATE DATABASE academia;
USE academia;

-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    apellido1 VARCHAR(50) NOT NULL,
    apellido2 VARCHAR(50),
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    dni VARCHAR(9) NOT NULL UNIQUE,
    tipo_usuario ENUM('administrador', 'profesor', 'tutor', 'alumno') NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de materias
CREATE TABLE IF NOT EXISTS materias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    descripcion TEXT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de relación profesor-materia
CREATE TABLE IF NOT EXISTS profesor_materia (
    profesor_id INT NOT NULL,
    materia_id INT NOT NULL,
    fecha_asignacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (profesor_id, materia_id),
    FOREIGN KEY (profesor_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (materia_id) REFERENCES materias(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de relación tutor-alumno
CREATE TABLE IF NOT EXISTS tutor_alumno (
    tutor_id INT NOT NULL,
    alumno_id INT NOT NULL,
    fecha_asignacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (tutor_id, alumno_id),
    FOREIGN KEY (tutor_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (alumno_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de notas
CREATE TABLE IF NOT EXISTS notas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    alumno_id INT NOT NULL,
    materia_id INT NOT NULL,
    profesor_id INT NOT NULL,
    nota DECIMAL(4,2) NOT NULL,
    trimestre TINYINT NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (alumno_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (materia_id) REFERENCES materias(id) ON DELETE CASCADE,
    FOREIGN KEY (profesor_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    UNIQUE KEY unique_nota (alumno_id, materia_id, trimestre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insertar usuario administrador por defecto
INSERT INTO usuarios (nombre, apellido1, apellido2, email, password, dni, tipo_usuario)
VALUES ('Admin', 'Sistema', NULL, 'admin@academia.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '00000000A', 'administrador')
ON DUPLICATE KEY UPDATE email = email;

-- Insertar algunos profesores de ejemplo
INSERT INTO usuarios (nombre, apellido1, apellido2, email, password, dni, tipo_usuario) VALUES
('Juan', 'García', 'López', 'juan.garcia@academia.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '11111111B', 'profesor'),
('María', 'Martínez', 'Sánchez', 'maria.martinez@academia.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '22222222C', 'profesor')
ON DUPLICATE KEY UPDATE email = email;

-- Insertar algunos tutores de ejemplo
INSERT INTO usuarios (nombre, apellido1, apellido2, email, password, dni, tipo_usuario) VALUES
('Carlos', 'Rodríguez', 'Pérez', 'carlos.rodriguez@academia.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '33333333D', 'tutor'),
('Ana', 'López', 'García', 'ana.lopez@academia.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '44444444E', 'tutor')
ON DUPLICATE KEY UPDATE email = email;

-- Insertar algunos alumnos de ejemplo
INSERT INTO usuarios (nombre, apellido1, apellido2, email, password, dni, tipo_usuario) VALUES
('Pedro', 'Sánchez', 'Martín', 'pedro.sanchez@academia.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '55555555F', 'alumno'),
('Laura', 'González', 'Ruiz', 'laura.gonzalez@academia.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '66666666G', 'alumno'),
('Miguel', 'Fernández', 'Torres', 'miguel.fernandez@academia.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '77777777H', 'alumno')
ON DUPLICATE KEY UPDATE email = email;

-- Insertar algunas materias de ejemplo
INSERT INTO materias (nombre, descripcion) VALUES
('Matemáticas', 'Asignatura de matemáticas generales'),
('Lengua', 'Asignatura de lengua española'),
('Historia', 'Asignatura de historia universal'),
('Física', 'Asignatura de física general'),
('Química', 'Asignatura de química general')
ON DUPLICATE KEY UPDATE nombre = nombre;
