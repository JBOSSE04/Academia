CREATE DATABASE IF NOT EXISTS academia;
USE academia;

CREATE TABLE roles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE usuarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    apellido1 VARCHAR(100) NOT NULL,
    apellido2 VARCHAR(100) NOT NULL,
    dni VARCHAR(10) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    rol_id INT NOT NULL,
    primer_login BOOLEAN DEFAULT TRUE,
    token VARCHAR(255),
    token_expiracion DATETIME,
    FOREIGN KEY (rol_id) REFERENCES roles(id)
);

CREATE TABLE materias (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE profesor_materia (
    profesor_id INT,
    materia_id INT,
    PRIMARY KEY (profesor_id, materia_id),
    FOREIGN KEY (profesor_id) REFERENCES usuarios(id),
    FOREIGN KEY (materia_id) REFERENCES materias(id)
);

CREATE TABLE alumnos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    apellido1 VARCHAR(100) NOT NULL,
    apellido2 VARCHAR(100) NOT NULL,
    fecha_nacimiento DATE
);

CREATE TABLE alumno_tutor (
    alumno_id INT,
    tutor_id INT,
    PRIMARY KEY (alumno_id, tutor_id),
    FOREIGN KEY (alumno_id) REFERENCES alumnos(id),
    FOREIGN KEY (tutor_id) REFERENCES usuarios(id)
);

CREATE TABLE notas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    alumno_id INT,
    materia_id INT,
    trimestre INT NOT NULL CHECK (trimestre IN (1,2,3)),
    nota DECIMAL(4,2) NOT NULL CHECK (nota >= 0 AND nota <= 10),
    profesor_id INT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (alumno_id) REFERENCES alumnos(id),
    FOREIGN KEY (materia_id) REFERENCES materias(id),
    FOREIGN KEY (profesor_id) REFERENCES usuarios(id),
    UNIQUE KEY unique_nota (alumno_id, materia_id, trimestre)
);

-- Insertar roles básicos
INSERT INTO roles (nombre) VALUES 
('gestor'),
('profesor'),
('tutor');

-- Insertar usuario gestor por defecto
-- Password: admin123 (se debe cambiar en primer login)
INSERT INTO usuarios (nombre, apellido1, apellido2, dni, email, username, password, rol_id) VALUES 
('Admin', 'Sistema', 'Academia', '00000000A', 'admin@academia.com', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1);
